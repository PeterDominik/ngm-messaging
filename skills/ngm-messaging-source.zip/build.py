#!/usr/bin/env python3
"""Build the ngm-messaging plugin and the n8n system prompt from one master file.

    python3 build.py            -> dist/ngm-messaging/ (plugin folder) + dist/n8n_system_prompt.txt
    python3 build.py --package  -> also dist/ngm-messaging.plugin

Edit master/ngm_manifest.yaml (framework content) or src/ (skills, guide, example, checker,
n8n wrapper), then rebuild. Never edit the generated reference files in dist/.
"""
import datetime
import json
import os
import shutil
import sys
import zipfile

import yaml

ROOT = os.path.dirname(os.path.abspath(__file__))
MASTER = os.path.join(ROOT, "master", "ngm_manifest.yaml")
SRC = os.path.join(ROOT, "src")
DIST = os.path.join(ROOT, "dist")
PLUGIN = os.path.join(DIST, "ngm-messaging")
PLUGIN_VERSION = "0.1.0"

LINES = open(MASTER, encoding="utf-8").read().split("\n")
DATA = yaml.safe_load("\n".join(LINES))
FW_VERSION = DATA["manifest"]["version"]


# ------------------------------------------------------------------ slicing the master (keeps comments)
def _indent(line):
    return len(line) - len(line.lstrip(" "))


def _is_key(line):
    s = line.strip()
    return bool(s) and not s.startswith("#") and not s.startswith("- ")


def block(path):
    """Return the YAML text of master[path...] with its comments, re-indented to top level."""
    start, end, level = 0, len(LINES), -2
    for key in path:
        level += 2
        found = None
        for i in range(start, end):
            ln = LINES[i]
            if _indent(ln) == level and ln.strip().startswith(key + ":"):
                found = i
                break
        if found is None:
            raise KeyError("/".join(path))
        stop = end
        for j in range(found + 1, end):
            ln = LINES[j]
            if _is_key(ln) and _indent(ln) <= level:
                stop = j
                break
        start, end = found, stop
    chunk = LINES[start:end]
    while chunk and (not chunk[-1].strip() or chunk[-1].strip().startswith("#")):
        chunk.pop()
    text = "\n".join(ln[level:] if ln.strip() else "" for ln in chunk)
    yaml.safe_load(text)  # every slice must stand on its own
    return text


def ref_md(title, intro, parts):
    body = [f"# {title}", "",
            f"_Generated from the NGM master framework {FW_VERSION}. Edit the master and rebuild; don't edit this file._", "",
            intro, ""]
    for heading, path in parts:
        body += [f"## {heading}", "", "```yaml", block(path), "```", ""]
    return "\n".join(body)


# ------------------------------------------------------------------ reference files
REFS = {
    "principles.md": ref_md(
        "Principles, procedure and ecosystem",
        "Apply the principles to every piece. The procedure is the working order; the ecosystem explains how the elements work together across many pieces.",
        [("Procedure and audience-facing language", ["framework", "llm_procedure"]),
         ("Principles", ["framework", "principles"]),
         ("Ecosystem", ["framework", "ecosystem"])]),
    "language-patterns.md": ref_md(
        "Language patterns",
        "Tools embedded inside any template. Name the pattern used in each beat's `pattern` field.",
        [("Patterns", ["framework", "language_patterns"])]),
    "titles.md": ref_md(
        "Titles — the blue door",
        "Title formulas by content type. Always return variants in different styles.",
        [("Title formulas", ["framework", "titles"])]),
    "templates-thought-reversal.md": ref_md(
        "Thought reversal templates",
        "Four templates for reversing one belief. Routing says which to pick when the request doesn't name one.",
        [("Templates", ["framework", "script_templates", "thought_reversal"]),
         ("Routing", ["framework", "routing", "thought_reversal"])]),
    "templates-connection.md": ref_md(
        "Connection templates",
        "Four formats for rallying around a shared belief, the deeper purpose or an identity.",
        [("Templates", ["framework", "script_templates", "connection"]),
         ("Routing", ["framework", "routing", "connection"])]),
    "templates-what-to-do.md": ref_md(
        "What-to-do (education) templates",
        "Six education types plus the special graphic formats. Teach WHAT, leave the full HOW for the offer.",
        [("Templates", ["framework", "script_templates", "what_to_do"]),
         ("Special formats", ["framework", "script_templates", "special"]),
         ("Routing", ["framework", "routing", "what_to_do"])]),
    "sales-mechanisms.md": ref_md(
        "Sales mechanisms",
        "How thought reversals, connection and education are used inside webinars, video series, sales videos, emails and ads.",
        [("Sales mechanisms", ["framework", "sales_mechanisms"])]),
    "formats.md": ref_md(
        "Formats, pacing and production styles",
        "Pacing and production styles apply to every spoken piece. Then use the adapter for the requested format.",
        [("Format adapters", ["framework", "format_adapters"])]),
    "quality-checklist.md": ref_md(
        "Quality checklist",
        "Run before delivering. The automatic checker covers pace, claims, jargon and shots; the rest is judgment.",
        [("Checklist", ["framework", "quality_checklist"])]),
    "topic-discovery.md": ref_md(
        "Topic discovery, content mix and testing",
        "How to find topics from beliefs, how much of each content type to make, and how to read results.",
        [("Topic discovery", ["framework", "topic_discovery"]),
         ("Content mix", ["framework", "content_mix"]),
         ("Messaging levels", ["framework", "evolution"]),
         ("Distribution and testing", ["framework", "distribution_and_testing"])]),
    "example.md": ref_md(
        "Worked example",
        "Structure illustration only: mirror the structure and level of detail, never borrow the content.",
        [("Example", ["framework", "example"])]),
    "crosswalk.md": ref_md(
        "Awareness stages and copy principles",
        "Which NGM tools fit each audience awareness stage, and where NGM covers classic copy principles.",
        [("Awareness stage to NGM", ["crosswalk", "awareness_stage_to_ngm"]),
         ("Copy principles overlap", ["crosswalk", "copy_principles_overlap"])]),
    "output-json.md": ref_md(
        "Generation request and output JSON",
        "Use for pipeline (n8n) work or when the user asks for JSON. The request fields also list the defaults a readable request resolves.",
        [("Generation request fields", ["generation_request"]),
         ("Output spec", ["output_spec"])]),
}

TEMPLATE_HEADER = f"""# ======================================================================================
#  CLIENT MESSAGING FILE — NGM framework {FW_VERSION}
#  One file per client, named <client-slug>-messaging.yaml, kept in the client's Claude project.
#  brand_context  = who the client is, who they serve, what's true      (filled once, updated rarely)
#  topic_bank     = beliefs, topics and what worked                        (grows every week)
#
#  RULES: leave a field empty rather than guess. Only true, confirmed content. Facts go in
#  facts.verified; things that aren't true go in facts.never_claim (+ never_claim_terms).
#  Multi-line answers use a block scalar, e.g.  description: >
# ======================================================================================

"""
CLIENT_TEMPLATE = TEMPLATE_HEADER + block(["brand_context"]) + "\n\n\n" + block(["topic_bank"]) + "\n"
yaml.safe_load(CLIENT_TEMPLATE)

SKILLS = {
    "ngm-script": ["principles.md", "language-patterns.md", "titles.md", "templates-thought-reversal.md",
                   "templates-connection.md", "templates-what-to-do.md", "sales-mechanisms.md", "formats.md",
                   "quality-checklist.md", "output-json.md", "example.md", "crosswalk.md"],
    "ngm-review": ["principles.md", "language-patterns.md", "templates-thought-reversal.md",
                   "templates-connection.md", "templates-what-to-do.md", "sales-mechanisms.md", "formats.md",
                   "quality-checklist.md", "output-json.md"],
    "ngm-topics": ["principles.md", "topic-discovery.md", "titles.md", "client-file-template.yaml"],
    "ngm-brand-setup": ["principles.md", "client-file-template.yaml", "elements-guide.md", "example-client-file.yaml"],
}
SCRIPTS = {"ngm-script": ["check_script.py"], "ngm-review": ["check_script.py"]}
EXTRA_SRC = {"elements-guide.md": os.path.join(SRC, "brand-setup", "elements-guide.md"),
             "example-client-file.yaml": os.path.join(SRC, "brand-setup", "example-client-file.yaml")}


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def build_plugin():
    if os.path.exists(PLUGIN):
        shutil.rmtree(PLUGIN)
    write(os.path.join(PLUGIN, ".claude-plugin", "plugin.json"), json.dumps({
        "name": "ngm-messaging",
        "version": PLUGIN_VERSION,
        "description": "New Generation Mastery messaging toolkit for the agency: build a client's messaging file, find belief-based topics, write scripts for any format from that file, and review scripts or pipeline output with automatic checks.",
        "author": {"name": "Peter"},
        "keywords": ["messaging", "copywriting", "scripts", "social media", "NGM"],
    }, indent=2) + "\n")
    shutil.copy(os.path.join(SRC, "README.md"), os.path.join(PLUGIN, "README.md"))
    for skill, refs in SKILLS.items():
        sdir = os.path.join(PLUGIN, "skills", skill)
        os.makedirs(sdir, exist_ok=True)
        shutil.copy(os.path.join(SRC, "skills", skill, "SKILL.md"), os.path.join(sdir, "SKILL.md"))
        for r in refs:
            dest = os.path.join(sdir, "references", r)
            if r in REFS:
                write(dest, REFS[r])
            elif r == "client-file-template.yaml":
                write(dest, CLIENT_TEMPLATE)
            else:
                os.makedirs(os.path.dirname(dest), exist_ok=True)
                shutil.copy(EXTRA_SRC[r], dest)
        for s in SCRIPTS.get(skill, []):
            dest = os.path.join(sdir, "scripts", s)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            shutil.copy(os.path.join(SRC, "scripts", s), dest)
            os.chmod(dest, 0o755)


def build_n8n():
    wrapper = open(os.path.join(SRC, "n8n", "system_wrapper.txt"), encoding="utf-8").read().rstrip() + "\n\n"
    parts = [f"<{k}>\n{block([k])}\n</{k}>\n" for k in ("framework", "output_spec", "crosswalk")]
    write(os.path.join(DIST, "n8n_system_prompt.txt"), wrapper + "\n".join(parts))


def package():
    out = os.path.join(DIST, "ngm-messaging.plugin")
    if os.path.exists(out):
        os.remove(out)
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        for base, _, files in os.walk(PLUGIN):
            for f in sorted(files):
                if f == ".DS_Store":
                    continue
                full = os.path.join(base, f)
                z.write(full, os.path.relpath(full, PLUGIN))
    return out


if __name__ == "__main__":
    build_plugin()
    build_n8n()
    print(f"built plugin {PLUGIN_VERSION} from framework {FW_VERSION} on {datetime.date.today()}")
    if "--package" in sys.argv:
        print("packaged", package())

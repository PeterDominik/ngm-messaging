# Maintaining the NGM plugin

This kit is the single source for the `ngm-messaging` plugin and the n8n script prompt. Change things here, rebuild, and both stay in sync.

## What's where

- `master/ngm_manifest.yaml`: the framework itself (principles, patterns, templates, formats, checklist, output shape) and the client-file template. Most fixes go here.
- `src/skills/<skill>/SKILL.md`: each skill's instructions.
- `src/brand-setup/`: the interview guide and the example client file.
- `src/scripts/check_script.py`: the automatic checker.
- `src/n8n/system_wrapper.txt`: the top of the n8n system prompt.
- `src/README.md`: the plugin's README.
- `build.py`: generates everything in `dist/`.

## Rebuild

```
pip install pyyaml
python3 build.py --package
```

This produces three things in `dist/`:

- `ngm-messaging/`: the plugin folder
- `ngm-messaging.plugin`: the file to install or share
- `n8n_system_prompt.txt`: paste into the n8n LLM node's system message

Before packaging a new version, bump `PLUGIN_VERSION` in `build.py`, add a line to the version history in `src/README.md`, and bump `manifest.version` in the master if the framework changed.

## Test after every change

```
python3 dist/ngm-messaging/skills/ngm-script/scripts/check_script.py tests/chatka_run1.json \
  --brand src/brand-setup/example-client-file.yaml --length 50        # must report 12 FAIL
python3 dist/ngm-messaging/skills/ngm-script/scripts/check_script.py tests/revised.txt \
  --brand src/brand-setup/example-client-file.yaml --length 53        # must PASS
```

## Rules for edits

- **Fix the framework in the master,** never in the generated `references/` files. The build overwrites them.
- **A rule the pipeline keeps breaking belongs in three places:** the master (principles and checklist), the checker if it can be measured, and `system_wrapper.txt` if n8n needs it spelled out.
- **Keep the client-file field names stable.** Add new fields with safe defaults so older client files keep working.

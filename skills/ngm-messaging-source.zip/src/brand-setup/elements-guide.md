# Messaging elements — interview guide

How to build each element of a client messaging file: what to ask, how to test the answer, and what goes wrong. Questions follow the NGM workbook exercises, reworded for an agency interviewing a client or its strategist. Ask a round at a time, 3-6 questions per message. Offer draft answers from the client's sources when you have them, labeled as proposals.

## Round 1 — Basics, production, voice

**Ask**
- What does the business sell, to whom, and where does it post (one main platform, then secondary)?
- Which languages do the posts go out in? Which is the default?
- Whose voice do the scripts speak in: the founder, a brand persona, or the agency writing as the brand?
- How is content made: voiceover over footage, captioned footage, someone talking on camera, or a mix? Who, if anyone, appears on camera? Where does footage come from?
- Can we get 150-300 words of the voice owner talking naturally (a voice note transcript, a podcast clip, an Instagram live)? Polished copy doesn't count.
- Words and phrases they never use? Profanity: none, light or natural?

**Tests**
- One main platform, not five.
- Pace: calm narration about 2.1-2.3 words per second, conversational 2.4-2.6, fast 2.7-2.9. Set `production.words_per_second`.
- No sample transcript yet: leave it empty and list it as the top gap. It is the strongest voice signal.

## Round 2 — Facts (do this before any messaging)

**Ask**
- What is true and checkable about the offer: capacity, features, locations, prices, times, guarantees, inclusions?
- What do people often assume the business has, but it doesn't? (Sauna, free delivery, 24/7 support…)

**Tests**
- `facts.verified` holds plain statements from the client or a source they gave, with no marketing language.
- `facts.never_claim` lists what is not true. `facts.never_claim_terms` lists the words for those things in every content language, so the checker can scan for them.
- Nothing from a competitor's site, a guess or "probably". Unknown is not the same as false: unknowns stay out of both lists.

## Round 3 — Struggling avatar (SA)

The identity the audience adopts as its own label AND wants to leave. Built from an older version of the founder, or from the favorite client when the founder never lived the problem (a doctor, a rental host).

**Ask**
- Before your best clients found you, what were they struggling with and feeling? List several (burned out, lost, working hard, stuck).
- What label did they give themselves, or what did they feel they were? Usually a noun: parent, founder, athlete, teacher.
- What do they do, think and say at that stage? Specific actions, times, numbers.

**Build**: adjective(s) + identity noun. "Overwhelmed educator", "Unheard entrepreneur". A softer version pairs a positive and a negative word: "Struggling but optimistic wanderer".

**Tests**
- Would the audience say "that's me" AND "I don't want to stay that"?
- The description is in their words, 2-4 sentences, with specifics.
- The name can change anytime. The audience never sees it as a label, so don't polish it for days.

## Round 4 — Future paced hero (FPH)

The identity they want to become, which comes out the other side of the unique solution. Ideally where the founder is now.

**Ask**
- What outcomes do they want, in 1-3 word phrases?
- How do they feel once they have them?
- What identity do they want, or what does the rest of the niche call itself?
- Is there a movement to create? What would it be called?

**Build**: an adjective or phrase from the outcomes and feelings, plus an identity noun. "Relaxed and free parent", "CEO mom". There must be a visible transformation from SA to FPH in the adjective, the noun, or both. Echoing the method's name helps ("Powerful founder" / "Powerful Founders Method") but isn't required.

## Round 5 — Unique solution

The client's own method that bridges SA to FPH, in 3-5 pillars. It separates them from "an expert in a sea of experts".

**Ask**
- List the process from SA to FPH in the fewest steps possible. Can any steps merge?
- Which ingredients must come together (in any order) for the result to happen?
- What 1-2 things make the client genuinely different?
- What main problem do they solve? (The problem, not what they do and not the audience's mistakes.)

**Tests**
- **10-expert test**: if 10 other experts in the space were asked for a process to get this result, would they give the same steps? If yes, the process isn't unique: switch to an element-based solution or build themes around the pillars.
- **Type**: `framework` = steps in order; `element` = ingredients that must combine, any order.
- 3-5 pillars. More than 5 means some should merge.
- Each pillar has what it is, the result it creates, and the pain when it's missing. Those pains feed the Desire But pattern and the One and More pattern.
- **Name**: the FPH (or a theme) + Effect / Method / Process / Solution.
- Renamed industry basics ("Lead Flow, Conversion, Fulfillment") are not unique.

## Round 6 — Diagnosis and common enemy

Whoever names the illness is who people go to for the cure.

**Ask**
- What specific pain does the audience have? Make it so specific they can't escape it. ("Posting 4+ times a week, content they know is good, still blending in.")
- What are they specifically doing that causes it? ("70% of posts are how-to, almost all in tutorial format.")
- What popular advice keeps the problem alive?

**Build**: name the problem. That name becomes the common enemy the client and the audience rally against ("Content Circle of Death").

**Tests**: symptoms, causes and advice are specific enough to self-diagnose. The name describes the problem, never a person or a competitor.

## Round 7 — Specific library

The fuel for every pattern. REAL, accurately specific material: numbers, time frames, frequencies, measurements, true for most of the audience.

**Ask**
- What does the SA feel, shown through behavior? ("Refreshes views every 20 minutes after posting" instead of "anxious".)
- What mistakes do they make, and what pain does each one cause? Which of those links do they NOT see? (Hidden causes are the strongest material.)
- What do they want, or what does the founder now have?
- Ready lines: "If you've been {pain} for more than {time}, you're {cause}."

**Tests**: every line has a number, time, frequency or concrete behavior. Desires are wishes, not features of the offer. The time-based identifier ends on the cause.

## Round 8 — Deeper purpose

NOT a result. The effect left on the world when 10,000 people have the result.

**Ask**
- What change do you want to see in the world, the country, the town or the industry? Does your work help create it?
- Imagine you crushed it on a stage and people told you it changed their life. What did you talk about?
- Your 3 strongest client results: how do their lives, and the lives of people around them, change?

**Build**: 3-4 sentences plus a one-liner. **Test**: if the "purpose" is something a client gets directly from the service, it's a result. Go one level up.

## Round 9 — Identity, values, boundaries

**Ask**
- Top 5 core values to bring into the business. Top 3 identities to make visible (parent, athlete, traveler…). These attract people like the founder.
- What has the founder wanted to say but held back out of fear of judgment?
- Hard lines: topics off limits, things never to do, emotions the audience never gets (anger, worry).

## Round 10 — Proof, offers, CTAs

**Ask**
- Stories: origin, turning points, client wins, failures and their lessons.
- Case studies with permission: who, before, after, timeframe.
- Well-known third-party examples that DO the client's solution and disprove a common belief: people, companies, books, films, traditions.
- Metaphors they already use.
- Lead magnet: name, small tangible promise (deliverable + result + timeframe), how to get it.
- Core offer: name, bigger promise, what's inside, what free content deliberately leaves out.
- Default CTA and a soft CTA.

**Tests**: counter examples are real and widely known. Stats are sourced. No invented testimonials.

## Optional seed — topic bank

If time allows, capture 3-5 belief-map rows (problem → action → belief → core belief) while the client is talking about mistakes. Mark each row with whether the belief hurts 70%+ of the people who hold it and whether it genuinely works for 30%+ (a pet peeve). `ngm-topics` builds the rest.

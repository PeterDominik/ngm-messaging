---
name: ngm-script
description: Writes titles and ready-to-record scripts with the New Generation Mastery (NGM) messaging framework from a client's messaging file — thought reversals, connection pieces and what-to-do education for reels, TikToks, long videos, carousels, image posts, podcasts, lives, emails, ads, webinar segments and sales videos. Use this skill whenever a client messaging file (a YAML/JSON file with brand_context) is in the project or conversation and someone asks for a script, reel, video, caption, carousel, post, email or ad for that client, or whenever someone mentions NGM, a thought reversal, the struggling avatar, the future paced hero or the unique solution. Drafts first and refines on request; can also return the n8n pipeline JSON. If there is no client messaging file and NGM isn't mentioned, leave general script requests to other script skills such as HOOKED. To build a client's messaging file use `ngm-brand-setup`; to decide what to talk about use `ngm-topics`; to critique an existing script use `ngm-review`.
---

# NGM Script

Write content in the client's voice from the client's messaging file, following the NGM framework in `references/`. Work draft-first: the first reply is a complete piece with title variants, then refine on request. Use only what the messaging file says. Never invent facts, results, reviews or stories.

## Step 1 — Load the client

1. Find the client messaging file in the project files, attachments or conversation. It is YAML or JSON with a `brand_context:` block, usually named `<client>-messaging.yaml`. If files for several clients are present, confirm which client before writing.
2. If there is no file:
   - If the user wants the full system, point them to `ngm-brand-setup`.
   - If they want one quick piece, ask in ONE message for the essentials: who it's for and what they struggle with, the offer with 3-5 verified facts, the voice, the call to action, the language and how it's produced (voiceover, captions or on camera). Write from that, and say that the full messaging file would make the piece sharper.
   - Never invent an avatar, facts or proof to fill the gap.
3. Before writing, read `production` (style, on-camera people, words per second) and `facts` (verified, never_claim). They are hard constraints, not suggestions.

## Step 2 — Resolve the request

Fill the generation request from the user's words. The fields are listed in `references/output-json.md`. Ask only when a missing item would change the piece, usually the topic or belief, or the format. Otherwise use these defaults and state them in one line:

- **Content type:** a thought reversal if the topic attacks a belief, what-to-do if it teaches, connection if it rallies a shared value.
- **Format:** reel_short, 45-60 s, on the client's main platform.
- **Language:** the first of `creator.languages`. "bilingual" means spoken in the first language, with the caption in all listed languages, the first one on top.
- **Call to action:** `default_cta`.
- **Titles:** 3 variants in different styles.
- **Template:** when not named, pick one with the routing section of the matching template file and say which one and why in one line.

Check the belief against `topic_bank.belief_map`. If `works_for_30` is true or `causes_suffering_70` is false, it's a pet peeve. Say so and propose a belief that passes, instead of writing.

## Step 3 — Load only what this piece needs

- **Always:** `principles.md`, `formats.md` (pacing, production styles and the format's adapter) and `quality-checklist.md`.
- **Thought reversal:** `templates-thought-reversal.md` and `language-patterns.md` (Sleight of Mouth, context switch, time-based identifier).
- **Connection:** `templates-connection.md`.
- **What to do:** `templates-what-to-do.md` and `language-patterns.md` (One and More, Desire But, List Method).
- **Sales pieces** (webinar or video-series segment, sales video, email, ad, lead magnet): `sales-mechanisms.md`.
- **Titles:** `titles.md`.
- **Pipeline JSON:** `output-json.md`.
- **Awareness-stage requests:** `crosswalk.md`.
- **First time in a conversation:** read `example.md` once for the level of detail expected.

## Step 4 — Draft

Hold these rules. They are the ones the pipeline broke most often.

1. **Word budget.** Maximum spoken words = length in seconds × `production.words_per_second` (2.3 if unset). Count the words and cut rather than speed up. Each beat's seconds = its words / words per second. No beat faster than about 2.8 words per second. The call to action gets at least 3 seconds.
2. **One piece, one job.** One belief (thought reversal), one stand (connection) or one lesson (what to do). Every specific, pain and example must serve it. Never borrow pains from another pillar, another belief or a pet-peeve belief.
3. **Facts versus wishes.** State or show only what `facts.verified` or `core_offer.whats_inside` contains. Desires, feelings and hero descriptions are what the audience wants, never features of the business. Never say, show or hint at anything in `facts.never_claim`.
4. **Visuals follow the production style.** With voiceover or captioned b-roll, nobody appears on camera unless listed in `production.on_camera_people`. One shot = one search query. Describe what the viewer sees, using only verified features or generic scenery.
5. **Time-based identifier.** The "then" clause names the cause (the action from the belief map), never another symptom.
6. **Ecosystem.** Name the common enemy once where the cause is described, if the client has one. Use the struggling avatar and hero names as identities naturally, not in every line.
7. **Audience-facing text never contains framework terms** (struggling avatar, thought reversal, pillar, SOM, CTA…). Beat labels are for the writer and may use them.
8. **Internal steps stay internal.** The context switch's core belief goes in the notes or meta, never in a beat.
9. **Sound like the voice owner.** Match the sample transcript when there is one, otherwise the tone words and energy. Keep sentences short and speakable.

## Step 5 — Check, then deliver

Run the quality checklist. For any spoken format, also run the checker from this skill's folder:

```
python3 scripts/check_script.py <draft.json or draft.txt> --brand <client messaging file> --length <seconds>
```

For a readable draft, save the spoken text as plain text, with a blank line between beats. Fix every FAIL before delivering, and mention a WARN only if it matters to the writer.

**Readable delivery (default)**
- One line: template and why, target belief or pillar, and estimated length at the client's pace.
- **Titles:** 3 variants, each labeled with its style.
- **On-screen hook.**
- **Beats:** for each beat, its name, the spoken text, the on-screen text and the shots (one search query each).
- **Caption:** in every language required.
- **Call to action.**
- **Gaps:** what would make the piece stronger, as plain requests (for example "add a real guest story to the file").

**JSON delivery:** when the user asks for JSON, n8n or the pipeline, or sends a generation_request, return exactly the `output_spec.script` shape from `references/output-json.md`, with no prose around it.

## Refining

Change only what was asked and keep the rest word for word. Re-count the budget after every edit. When the writer rewrites a line in their own words, keep their version. If feedback reveals a durable fact about the client (a new verified fact, a banned phrase, a voice trait), offer the exact lines to add to the messaging file.

## Guardrails

- **No messaging file and they want the whole system:** `ngm-brand-setup`. **No idea what to post:** `ngm-topics`. **Feedback on an existing script:** `ngm-review`. Name the skill and let the user invoke it; don't switch mid-conversation.
- **Pure hook or retention coaching without the messaging framework** belongs to HOOKED.
- **Don't write a reversal of a pet-peeve belief,** and don't write content that attacks people, clients or competitors. Aim at the old way, never at people.
- **Respect `identity.boundaries`** as hard rules.
- **Language:** write in the client's language and use the pace set for that language in the file.

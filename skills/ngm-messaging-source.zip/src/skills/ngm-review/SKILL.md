---
name: ngm-review
description: Reviews an existing script, caption, carousel, email or n8n pipeline output against the New Generation Mastery (NGM) messaging framework and the client's messaging file. Runs automatic checks (speaking pace, empty beats, claims not in the verified facts, framework jargon, one search query per shot), then a judgment pass on facts, the one-belief rule, template structure and voice, and returns ranked fixes with a corrected version. Use whenever someone says "review this script", "check this output", "score this reel", "is this ready to record", "why didn't this post work", pastes or attaches a script or pipeline JSON for a client that has a messaging file, or asks for an NGM review. To write a new piece use `ngm-script`; for hook and open-loop analysis without the messaging framework use HOOKED's video script analyzer.
---

# NGM Review

Judge a finished piece against the NGM framework and the client's messaging file, then hand back fixes the writer can apply in minutes. Verify everything yourself. The piece's own `self_check` or `needs` claims are not evidence: the pipeline has passed its own checks while breaking five rules.

## Step 1 — Identify what's being reviewed

- **The piece:** NGM pipeline JSON (possibly wrapped, like `[{"text": "{...}"}]`), a readable script, a caption, carousel slides or an email.
- **The client messaging file:** in the project, attached or pasted. Without it, review against the framework only and say that facts and claims could not be verified.
- **The intent:** target length, format, platform, target belief or lesson, and call to action. Take these from the request or the piece's meta. If they're missing, infer them from the piece and state what you assumed.

## Step 2 — Automatic checks

Save the piece to a file and run the checker from this skill's folder:

```
python3 scripts/check_script.py <piece.json or piece.txt> --brand <client messaging file> --length <seconds>
```

It catches the mechanical failures: beats spoken too fast, a total over the word budget, a wrong word count, empty or internal beats, never-claim terms and banned words, framework jargon in audience text, a person on camera when the production style has nobody, and one search holding several shots. For plain text, separate beats with blank lines.

## Step 3 — Judgment pass

Work through these in order. The most expensive problems come first.

1. **Facts.** Every stated or shown feature must trace to `facts.verified` or `core_offer.whats_inside`. Look for desires presented as features ("the big table"), visuals that assume unconfirmed things (materials, rooms, people), and anything from `facts.never_claim`.
2. **One job.** Exactly one belief, stand or lesson. Check that every context question, pain and example serves it, with nothing borrowed from another pillar or a pet-peeve belief.
3. **Structure.** The template's steps are present and in order (`templates-*.md`). For thought reversals:
   - compassion is present
   - the discredit uses a named Sleight of Mouth move and can't reasonably be argued
   - any counter example actually does the solution
   - any time-based identifier ends on the cause
   - the choose step contrasts pain with benefit
   - the call to action is clear
4. **Pace and format fit.** From the checker, plus whether the format's adapter rules hold (`formats.md`).
5. **Ecosystem use.** The struggling avatar, hero and common enemy are used where they would help, and the meta lists only what the text actually contains.
6. **Voice and language.** Would the voice owner say this out loud? Flag clunky or unnatural phrasing in the target language with a better line.
7. **Pipeline hygiene.** JSON shape (`output-json.md`), `needs` in `[NEEDS: path]` form, and one search query per shot.

## Step 4 — Deliver

- **Verdict, one line:** ready to record, fix before recording, or rewrite.
- **What works:** 2-3 short bullets. Be specific, not flattering.
- **Issues, ranked by cost:** at most 7, with minor ones grouped. For each, give what's wrong, where (the beat), why it matters, and the fix.
- **Corrected version:** the spoken script (and on-screen text or shots where they changed), within the word budget. Keep the writer's lines wherever they already work. State the word count and length at the client's pace.
- **Prevention:** what to add to the messaging file or the request so it doesn't happen again. For example: a fact, a never_claim term, the production style, or a rule for the n8n prompt.

For a batch of pipeline outputs, give a short table (piece, verdict, top issue), then the details for the pieces that failed.

## Guardrails

- Review against the framework and the client's file, not personal taste. Don't rewrite a piece that needs two fixes.
- Don't approve a piece with an unverified claim or a pet-peeve reversal, however good the writing is.
- **Writing a new piece from scratch:** `ngm-script`. **Planning topics:** `ngm-topics`. **Hook and retention diagnosis only:** HOOKED's analyzer. Name the skill; don't switch mid-conversation.
- Respond in the language of the conversation, but quote and fix script lines in the script's language.

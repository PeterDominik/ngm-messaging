---
name: ngm-topics
description: Finds what a client should talk about using the New Generation Mastery (NGM) messaging framework. Builds the belief map (problem → action → belief), filters out pet peeves, answers the per-pillar questions, and produces a topic shortlist with title options and a content-mix plan; also turns post performance into winners, retests, new angles and campaign picks. Use when someone asks "what should we post about", "content ideas for [client]", "topic list", "content plan", "belief map", "thought reversal topics", "what beliefs should we attack", or shares post results and asks what to do next, for a client with a messaging file. To write a specific piece use `ngm-script`; to build the client's messaging file first use `ngm-brand-setup`.
---

# NGM Topics

Turn a client's messaging file into topics worth making, and turn results into the next round. Topics come from the client's real audience problems and beliefs, not from trends or from what the audience says it wants.

## Step 1 — Load the client

Find the client messaging file (project files, attachments or the conversation; YAML or JSON with `brand_context:`). This skill needs at least the struggling avatar, the unique solution pillars, and some diagnosis or specific-library material.

- **No file:** point to `ngm-brand-setup`.
- **A thin file:** say which gaps limit the topics and continue with what's there.

Read `references/topic-discovery.md`, `references/titles.md` and `references/principles.md`.

## Step 2 — Pick the mode

- **Ideation:** a new or empty topic bank, or "give us ideas".
- **Extend:** a topic bank exists and they want more, or topics for one pillar or campaign.
- **Performance:** results are pasted or attached (views, watch time, saves, shares, comments, ThruPlay cost).

## Ideation and extend

1. **Belief map.** Build 5-10 rows of problem → action → belief → core belief, working backwards from specific problems. Use the diagnosis, the specific library and the per-scope answers. Where the file is thin, propose rows as questions for the strategist and label them **unconfirmed** ("Is it true that most of their customers…?").
2. **Pet-peeve filter.** Mark each belief with whether it hurts 70%+ of the people who hold it, and whether it genuinely works for 30%+. Only beliefs that hurt most people and work for few become thought reversals. Show the dropped ones and why.
3. **Per-scope questions.** For the unique solution and each pillar, cover: misconceptions, outdated norms, limiting beliefs, objections to listening and to buying, the most backwards thing, the elements or steps, the effect when it's dialed in, beliefs to stand up for, the biggest change wanted, and shared beliefs. Fill from the file and propose the rest as unconfirmed.
4. **Shortlist, as topics, not titles:**
   - Thought reversals: up to 10, with the 5 most relatable belief-map beliefs first.
   - What-to-do: up to 10, with 5 "how to fix {problem}" first, then pillar steps. Pick what most people need, not favorites.
   - Connection: deeper purpose, traditional shared beliefs, and 3-4 identity themes.
   - Self-identifying education: topics that exist because of a misconception.
   - Every thought reversal and what-to-do topic maps to a pillar.
5. **For each topic:** give 2-3 title options in different styles from `titles.md`, the pillar, a suggested format, and the belief for thought reversals.
6. **Mix plan.** Use the content mix for the client's niche state (stagnant or ready for change). Suggest a 2-4 week plan (for example 12 posts), rotating thought-reversal formats (original, context switch, self-identify) and keeping about half video.

**Deliver:**
- a short summary
- the tables (belief map, shortlist, plan)
- a YAML block of new `topic_bank` entries ready to paste into the messaging file, with unconfirmed items marked by a `# unconfirmed` comment

## Performance

1. **Read the numbers.** Organic posts: judge high-effort signals first (saves, shares, comments), then view time. ThruPlay tests: judge average watch time first, then engagement.
2. **Give each piece a verdict:** winner, retest with a new title, retest with a new angle, or drop. The workbook's rule: a liked topic that flopped gets a new title or angle before it's dropped.
3. **For winners:**
   - 3 new titles and 2 other formats for the same topic
   - whether it's campaign-ready: a thought-reversal or what-to-do winner becomes a webinar or video-series title, "How to {benefit} without {belief}", and an ad headline
   - reuse the winning language
4. **Deliver:** the verdict table, next actions, and `performance_log` YAML entries to paste into the file.

## Guardrails

- Never invent audience facts or numbers. Anything not in the file or the user's words is marked unconfirmed.
- No pet peeves as reversals, no trend-chasing, and no topics outside the unique solution, the deeper purpose or the client's values and identities (the northstar rule).
- The topic bank stores topics, not titles. Titles are options attached to topics.
- **Writing a piece from a topic:** `ngm-script`. **Critiquing a piece:** `ngm-review`. **Building or updating the messaging file:** `ngm-brand-setup`.

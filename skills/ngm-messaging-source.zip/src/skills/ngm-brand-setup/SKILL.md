---
name: ngm-brand-setup
description: Builds or updates a client's messaging file for the New Generation Mastery (NGM) framework by interviewing the strategist or the client — production style and voice, verified facts, struggling avatar, future paced hero, unique solution and pillars, diagnosis and common enemy, specific library, deeper purpose, values and boundaries, proof and offers — and delivers it as a file to add to the client's Claude project. Use when someone says "set up a new client", "onboard [client]", "build the messaging file", "define the avatar", "name the unique solution", "find the common enemy", "update [client]'s messaging", "add this fact to the file", or when another NGM skill needs a client file that doesn't exist. Writing scripts is `ngm-script`; topic ideas and belief maps are `ngm-topics`; critiquing a script is `ngm-review`.
---

# NGM Brand Setup

Produce one client messaging file, `<client-slug>-messaging.yaml`, in the exact shape of `references/client-file-template.yaml`. Every other NGM skill reads this file, so what's in it decides what they can write. Its value comes from being true and specific, not from being complete. An empty field is better than a guessed one.

## Step 0 — New file or update?

- **An existing file** (in the project, attached or pasted): load it, list its gaps ranked by how much they limit scripts (see Step 5), and work only on what the user wants now.
- **A small update** ("add this fact", "they now offer X"): make the change, bump nothing else, and deliver the updated file.
- **A new client:** go on to Step 1.

## Step 1 — Collect sources before asking

Ask once for anything that already exists: website, brand or strategy docs, past top posts, video or podcast transcripts, reviews, onboarding call notes. Read what's provided; fetch a website if a URL is given. Extract:

- **Facts** into `facts.verified`, only when a source states them plainly. Note the source in a comment.
- **Voice material:** real spoken transcripts only.
- **Candidate specifics:** mistakes, pains and desires in the audience's own words, from reviews and comments.

Everything drawn from sources is a proposal until the user confirms it.

## Step 2 — Interview in rounds

Follow `references/elements-guide.md`. It gives the questions, how to build each element, and the quality tests. Order:

1. Basics, production and voice
2. Facts
3. Struggling avatar
4. Future paced hero
5. Unique solution
6. Diagnosis and common enemy
7. Specific library
8. Deeper purpose
9. Identity, values and boundaries
10. Proof, offers and calls to action

- Ask 3-6 questions per message, one round at a time. Offer draft answers from the sources, clearly labeled as proposals.
- Accept "skip" or "don't know" and move on. Leave the field empty and note it as a gap.
- For an agency, the "creator" is whoever owns the voice (`creator.voice_owner`): the founder, a brand persona, or the agency writing as the brand. Identity and values belong to that voice.
- If the user wants speed, combine rounds 3-7 into one message and propose everything from the sources for them to correct.

## Step 3 — Build the named elements

For the struggling avatar, future paced hero, unique solution name and common enemy, offer 2-3 options each and let the user pick. Apply the tests from the guide:

- The struggling avatar is adjective(s) plus an identity noun that the audience would adopt AND want to leave.
- The future paced hero shows a visible transformation from the avatar.
- The unique solution passes the 10-expert test. If it doesn't, suggest an element-based version or themes. It has 3-5 pillars, each with the pain when that pillar is missing.
- The deeper purpose is an effect on the world, not a client result.
- The diagnosis is specific enough to self-diagnose. The enemy names a problem, never a person or competitor.
- Specifics carry numbers, time frames or concrete behavior. Desires are wishes, not features.
- Counter examples are real, widely known, and actually do the solution.

Offer to fill `unique_solution.desire_but` from the pillars once all 3 are confirmed.

## Step 4 — Write the file

- Follow the template's structure and field names exactly. Keep its comments for fields that are still empty, so the next person knows what goes there.
- Write only confirmed content. Keep unconfirmed proposals out, or add them with a `# unconfirmed` comment if the user asks.
- `facts.verified`: plain, checkable statements with no adjectives or marketing language.
- `facts.never_claim`: what's not true. `facts.never_claim_terms`: the words for those things in every content language the client posts in, so the checker can scan for them.
- Set `production.words_per_second` to match the voice: calm 2.1-2.3, conversational 2.4-2.6, fast 2.7-2.9.
- Optionally seed `topic_bank.belief_map` with rows captured during the interview. `ngm-topics` builds the rest.
- `references/example-client-file.yaml` shows the level of detail a finished file has. Use its shape, never its content.

Save the file and send it to the user.

## Step 5 — Deliver

- The file.
- A summary: the named elements with one line each, and the pillars.
- **Gaps, ranked by impact on scripts:**
  1. the voice sample transcript
  2. verified facts
  3. mistakes with hidden causes
  4. proof (stories, case studies, counter examples)
  5. the deeper purpose
  6. the lead magnet
- **How to use it:** add the file to the client's Claude project files, replacing any older version, so every chat in that project has it. The same file can feed the n8n pipeline.

## Guardrails

- Never invent facts, results, reviews, testimonials, numbers or customer stories. A "typical" example isn't a real one.
- One client per file. Never mix details from two clients.
- Keep the client's customers' personal data out of the file (names, contact details, health or financial details). Use anonymized case studies only with permission.
- Don't make claims the client can't substantiate, such as guarantees or medical or financial results. Flag them to the strategist.
- **Scripts:** `ngm-script`. **Topics and belief maps:** `ngm-topics`. **Script critique:** `ngm-review`.

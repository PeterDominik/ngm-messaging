# NGM Messaging

The agency's messaging toolkit, built on Brandon Lucero's **New Generation Mastery (NGM)** messaging framework. It turns a client's messaging, meaning who they serve, what's true about them and what they stand for, into content that shifts beliefs and creates demand instead of blending in. For internal agency use.

## Skills

- **ngm-brand-setup** — Interviews the strategist or client and builds the client's **messaging file**: production style and voice, verified facts, struggling avatar, future paced hero, unique solution and pillars, diagnosis and common enemy, specific library, deeper purpose, values, proof and offers.
- **ngm-topics** — Builds the belief map, filters out pet peeves and produces a topic shortlist with title options and a content-mix plan. Also reads post results and decides winners, retests and campaign picks.
- **ngm-script** — Writes titles and a ready-to-record script from the messaging file for any format: reel, long video, carousel, image post, podcast, live, email, ad, webinar segment or sales video. Drafts first, refines on request, and returns n8n pipeline JSON when asked.
- **ngm-review** — Reviews an existing script or pipeline output. Runs automatic checks (pace, empty beats, claims not in the facts, framework jargon, one search per shot), then gives ranked fixes and a corrected version.

The skills point to each other by name when a request fits a sibling better.

## Which skill to use

- New client, or the client's messaging changed → **ngm-brand-setup**
- "What should we post about?" or "here are last month's results" → **ngm-topics**
- "Write a reel, carousel, email or ad for [client]" → **ngm-script**
- "Is this script ready?" or "check this output" → **ngm-review**

## Setup: one Claude project per client

1. Create a Claude project for the client.
2. Run **ngm-brand-setup** in it and add the resulting `<client>-messaging.yaml` to the project's files. Replace the old version whenever it's updated.
3. From then on, any script request in that project uses the messaging framework. Without a messaging file, general script requests are left to other script tools such as HOOKED.

The messaging file only holds confirmed information. Empty fields are fine; guessed ones are not. The two most valuable additions after setup are a real voice sample (a transcript of the voice owner talking naturally) and real proof (stories, case studies).

## Automatic checks

`ngm-script` and `ngm-review` include a checker that measures speaking pace against the client's words-per-second setting and flags:

- empty or internal beats
- never-claim terms and banned words
- framework jargon in audience-facing text
- someone on camera when the client's production style has nobody
- one search query holding several shots

It works on pipeline JSON and on plain-text scripts.

## n8n pipeline

The same messaging file feeds the n8n script node. Build the user message from `brand_context`, `topic_bank` and a `generation_request`. The system prompt is built from the same master framework as these skills, so a fix to the framework reaches both. Run the checker, or its logic in a Code node, on every pipeline output before rendering.

## Version history

- **0.1.0** — First release. Four skills built from the NGM master framework 1.1. It includes the fixes from the first pipeline test:
  - word budget per length and speaking pace
  - production style and verified-facts blocks
  - one belief per piece
  - time-based identifiers end on the cause
  - one search query per shot

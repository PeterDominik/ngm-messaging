#!/usr/bin/env python3
"""NGM script checker — the deterministic checks an LLM self-check misses.

Usage:
  python3 check_script.py SCRIPT [--brand CLIENT_FILE] [--length SECONDS] [--wps N] [--json]

SCRIPT       NGM output JSON (the output_spec.script shape, a raw n8n reply such as
             [{"text": "{...}"}], or a file holding that JSON) or a plain-text script
             (blank lines separate beats).
--brand      The client's messaging file (YAML or JSON). Supplies words per second,
             production style, never-claim terms and banned words.
--length     Target length in seconds. Defaults to meta.est_duration_s or the sum of beats.
--wps        Speaking pace override (words per second).
--json       Print the report as JSON instead of text.

Exit code 1 when any FAIL is found, 0 otherwise. Standard library only; PyYAML is used
if installed, otherwise a small fallback reads the few brand fields the checker needs.
"""
import argparse
import json
import re
import sys

DEFAULT_WPS = 2.3
MAX_BEAT_WPS = 2.8
MIN_CTA_SECONDS = 3
JARGON = [
    "struggling avatar", "future paced hero", "future-paced hero", "thought reversal",
    "sleight of mouth", "common enemy", "unique solution", "pet peeve", "context switch",
    "desire but", "one and more", "time based identifier", "time-based identifier",
    "messaging ecosystem", "deeper purpose",
]
JARGON_CASED = ["SOM", "CTA", "FPH"]  # only flagged when written in capitals
ON_CAMERA_HINTS = [
    "talking to camera", "talks to camera", "to camera", "talking head", "on camera",
    "host on", "host standing", "host talking", "presenter", "selfie video",
]
MULTI_SHOT = re.compile(r"\s/\s|;|\s\+\s|\bthen\b", re.I)
WORD = re.compile(r"\w+(?:[-'’.]\w+)*", re.UNICODE)


def words(text):
    return len(WORD.findall(text or ""))


# ---------------------------------------------------------------- loading
def load_script(path):
    raw = open(path, encoding="utf-8").read()
    try:
        data = json.loads(raw)
    except json.JSONDecodeError:
        return {"mode": "text", "text": raw}
    # n8n / LLM wrappers: [{"text": "{...}"}] or {"text": "{...}"} or {"output": ...}
    for _ in range(3):
        if isinstance(data, list) and data and isinstance(data[0], dict):
            data = data[0]
        if isinstance(data, dict) and "sections" not in data:
            inner = data.get("text") or data.get("output") or data.get("content")
            if isinstance(inner, str):
                try:
                    data = json.loads(inner.strip().strip("`").removeprefix("json").strip())
                    continue
                except json.JSONDecodeError:
                    return {"mode": "text", "text": inner}
            elif isinstance(inner, (dict, list)):
                data = inner
                continue
        break
    if isinstance(data, dict) and "sections" in data:
        return {"mode": "json", "data": data}
    return {"mode": "text", "text": raw}


def _fallback_brand(text):
    """Read the handful of fields the checker needs without PyYAML."""
    out = {"production": {}, "facts": {}, "voice": {}}
    m = re.search(r"^\s*words_per_second:\s*([\d.]+)", text, re.M)
    if m:
        out["production"]["words_per_second"] = float(m.group(1))
    m = re.search(r"^\s*style:\s*([a-z_]+)", text, re.M)
    if m:
        out["production"]["style"] = m.group(1)

    def grab_list(key):
        m = re.search(rf"^(\s*){key}:\s*\[(.*?)\]", text, re.M | re.S)
        if m:
            return [x.strip().strip("'\"") for x in m.group(2).split(",") if x.strip()]
        m = re.search(rf"^(\s*){key}:\s*(?:#.*)?\n((?:\1\s+-.*\n?)+)", text, re.M)
        if m:
            return [re.sub(r"^\s*-\s*", "", ln).split(" #")[0].strip().strip("'\"")
                    for ln in m.group(2).splitlines() if ln.strip()]
        return []

    out["facts"]["never_claim_terms"] = grab_list("never_claim_terms")
    out["voice"]["words_never_used"] = grab_list("words_never_used")
    m = re.search(r"^\s*on_camera_people:\s*\[(.*?)\]", text, re.M)
    out["production"]["on_camera_people"] = [x.strip() for x in m.group(1).split(",") if x.strip()] if m else []
    return out


def load_brand(path):
    if not path:
        return {}
    text = open(path, encoding="utf-8").read()
    data = None
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        try:
            import yaml  # type: ignore
            data = yaml.safe_load(text)
        except ImportError:
            return _fallback_brand(text)
    if isinstance(data, dict) and "brand_context" in data:
        data = data["brand_context"]
    return data or {}


# ---------------------------------------------------------------- checks
class Report:
    def __init__(self):
        self.items = []

    def add(self, level, where, msg):
        self.items.append({"level": level, "where": where, "message": msg})

    @property
    def fails(self):
        return [i for i in self.items if i["level"] == "FAIL"]


def find_terms(text, terms):
    hits = []
    low = (text or "").lower()
    for t in terms:
        t = (t or "").strip()
        if t and re.search(rf"(?<!\w){re.escape(t.lower())}(?!\w)", low):
            hits.append(t)
    return hits


def find_jargon(text):
    hits = find_terms(text, JARGON)
    for t in JARGON_CASED:
        if re.search(rf"(?<!\w){t}(?!\w)", text or ""):
            hits.append(t)
    return hits


def audience_texts(d):
    """(where, text) pairs the audience sees or hears."""
    out = [("on_screen_hook", d.get("on_screen_hook"))]
    for i, t in enumerate(d.get("titles") or []):
        out.append((f"title {i + 1}", t.get("text") if isinstance(t, dict) else t))
    for s in d.get("sections") or []:
        name = s.get("step", "?")
        out += [(f"{name} / spoken", s.get("spoken")), (f"{name} / on-screen", s.get("on_screen_text"))]
    out.append(("caption", d.get("caption")))
    for i, sl in enumerate(d.get("slides") or []):
        out.append((f"slide {i + 1}", sl if isinstance(sl, str) else json.dumps(sl, ensure_ascii=False)))
    email = d.get("email") or {}
    out += [("email subject", " | ".join(email.get("subject_lines") or [])), ("email body", email.get("body"))]
    ad = d.get("ad") or {}
    out += [("ad headlines", " | ".join(ad.get("headline_variants") or [])), ("ad text", ad.get("primary_text"))]
    cta = d.get("cta") or {}
    out.append(("cta", cta.get("text") if isinstance(cta, dict) else cta))
    return [(w, t) for w, t in out if t]


def visual_texts(d):
    out = []
    for s in d.get("sections") or []:
        name = s.get("step", "?")
        if s.get("visual_note"):
            out.append((f"{name} / visual", s["visual_note"]))
        for j, sh in enumerate(s.get("shots") or []):
            if isinstance(sh, dict):
                out.append((f"{name} / shot {j + 1}", f"{sh.get('description', '')} {sh.get('query', '')}"))
        if s.get("broll_query"):
            out.append((f"{name} / broll_query", s["broll_query"]))
    return out


def check_json(d, brand, args, rep):
    prod = brand.get("production") or {}
    facts = brand.get("facts") or {}
    voice = brand.get("voice") or {}
    meta = d.get("meta") or {}
    wps = args.wps or prod.get("words_per_second") or meta.get("words_per_second") or DEFAULT_WPS
    style = prod.get("style") or meta.get("production_style")
    sections = d.get("sections") or []
    spoken_kinds = {"reel_short", "video_long", "live", "podcast_episode", "ad",
                    "webinar_segment", "video_series_segment", "sales_video", None}
    spoken_format = meta.get("format") in spoken_kinds

    if not sections:
        rep.add("FAIL", "sections", "No sections returned.")
    total_words, total_secs = 0, 0
    for s in sections:
        name = s.get("step", "?")
        spoken = s.get("spoken") or ""
        w = words(spoken)
        secs = s.get("est_seconds") or 0
        total_words += w
        total_secs += secs
        if spoken_format and w == 0 and style != "captioned_broll":
            if secs == 0:
                rep.add("FAIL", name, "Empty beat with 0 seconds — an internal step was returned as a section. Remove it (core belief goes in meta.core_belief).")
            else:
                rep.add("FAIL", name, "Beat has no spoken text.")
        if style == "captioned_broll" and not (s.get("on_screen_text") or "").strip():
            rep.add("FAIL", name, "Captioned style needs on-screen text in every beat.")
        if w and secs:
            rate = w / secs
            if rate > MAX_BEAT_WPS + 0.2:
                rep.add("FAIL", name, f"{w} words in {secs} s = {rate:.1f} words/s (limit about {MAX_BEAT_WPS}). Needs about {round(w / wps)} s or fewer words.")
            elif rate > MAX_BEAT_WPS:
                rep.add("WARN", name, f"{rate:.1f} words/s is on the fast side.")
        elif w and not secs:
            rep.add("WARN", name, "No est_seconds on a spoken beat.")
        low = name.lower()
        if ("cta" in low or "call to action" in low) and w and w / wps < MIN_CTA_SECONDS - 0.5 and secs < MIN_CTA_SECONDS:
            rep.add("WARN", name, f"CTA gets {secs} s; give it at least {MIN_CTA_SECONDS} s.")
        for j, sh in enumerate(s.get("shots") or []):
            q = sh.get("query", "") if isinstance(sh, dict) else str(sh)
            if not q.strip():
                rep.add("FAIL", f"{name} / shot {j + 1}", "Shot has no search query.")
            elif MULTI_SHOT.search(q):
                rep.add("FAIL", f"{name} / shot {j + 1}", f"Query looks like several shots in one: \"{q}\". Split into one query per shot.")
        bq = s.get("broll_query")
        if bq:
            if MULTI_SHOT.search(bq) or bq.count(",") >= 2:
                rep.add("FAIL", name, f"broll_query packs several shots into one search: \"{bq}\". Use a shots list, one query each.")
            else:
                rep.add("WARN", name, "Uses broll_query; the 1.1 format is a shots list with one query per shot.")

    length = args.length or meta.get("est_duration_s") or total_secs
    if spoken_format and total_words:
        budget = length * wps
        need = total_words / wps
        if total_words > budget * 1.10:
            rep.add("FAIL", "total", f"{total_words} spoken words need about {need:.0f} s at {wps} words/s, but the piece is {length} s. Cut to about {int(budget)} words.")
        elif total_words < budget * 0.75:
            rep.add("WARN", "total", f"Only {total_words} words for {length} s ({need:.0f} s of speech) — fine if visuals carry the rest.")
        claimed = meta.get("word_count")
        if isinstance(claimed, (int, float)) and abs(claimed - total_words) > max(3, 0.05 * total_words):
            rep.add("WARN", "meta.word_count", f"Says {claimed}, real count is {total_words}.")
        if total_secs and abs(total_secs - length) > max(3, 0.1 * length):
            rep.add("WARN", "est_seconds", f"Beats add up to {total_secs} s, target is {length} s.")

    banned = list(facts.get("never_claim_terms") or []) + list(voice.get("words_never_used") or [])
    for where, text in audience_texts(d) + visual_texts(d):
        for t in find_terms(text, banned):
            rep.add("FAIL", where, f"Contains \"{t}\" (never-claim term or banned word).")
    for where, text in audience_texts(d):
        for t in find_jargon(text):
            rep.add("FAIL", where, f"Framework term \"{t}\" in audience-facing text.")

    people = prod.get("on_camera_people") or []
    if style in ("voiceover_broll", "captioned_broll") and not people:
        for where, text in visual_texts(d):
            hits = find_terms(text, ON_CAMERA_HINTS)
            if hits:
                rep.add("FAIL", where, f"Puts someone on camera (\"{hits[0]}\") but the production style is {style} with nobody listed on camera.")

    for n in d.get("needs") or []:
        if not str(n).startswith("[NEEDS:"):
            rep.add("WARN", "needs", f"Not in [NEEDS: path] form: {str(n)[:60]}")

    return {"words": total_words, "wps": wps, "length_s": length,
            "speech_s": round(total_words / wps, 1) if wps else None, "style": style}


def check_text(text, brand, args, rep):
    prod = brand.get("production") or {}
    facts = brand.get("facts") or {}
    voice = brand.get("voice") or {}
    wps = args.wps or prod.get("words_per_second") or DEFAULT_WPS
    beats = [b for b in re.split(r"\n\s*\n", text) if b.strip()]
    total = words(text)
    if args.length:
        budget = args.length * wps
        if total > budget * 1.10:
            rep.add("FAIL", "total", f"{total} words need about {total / wps:.0f} s at {wps} words/s; target {args.length} s. Cut to about {int(budget)} words.")
        elif total < budget * 0.75:
            rep.add("WARN", "total", f"Only {total} words for {args.length} s.")
    banned = list(facts.get("never_claim_terms") or []) + list(voice.get("words_never_used") or [])
    for i, b in enumerate(beats, 1):
        for t in find_terms(b, banned):
            rep.add("FAIL", f"beat {i}", f"Contains \"{t}\" (never-claim term or banned word).")
        for t in find_jargon(b):
            rep.add("FAIL", f"beat {i}", f"Framework term \"{t}\" — check it isn't in audience-facing text.")
    return {"words": total, "wps": wps, "length_s": args.length, "speech_s": round(total / wps, 1), "beats": len(beats)}


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("script")
    ap.add_argument("--brand")
    ap.add_argument("--length", type=float)
    ap.add_argument("--wps", type=float)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()

    script = load_script(args.script)
    brand = load_brand(args.brand)
    rep = Report()
    if script["mode"] == "json":
        stats = check_json(script["data"], brand, args, rep)
    else:
        stats = check_text(script["text"], brand, args, rep)
    stats["mode"] = script["mode"]
    stats["brand_file"] = bool(args.brand)

    if args.json:
        print(json.dumps({"stats": stats, "issues": rep.items, "pass": not rep.fails}, ensure_ascii=False, indent=2))
    else:
        print(f"NGM check — {stats['mode']} | {stats.get('words')} words | {stats.get('speech_s')} s at {stats.get('wps')} w/s"
              + (f" | target {stats['length_s']} s" if stats.get("length_s") else "")
              + ("" if args.brand else " | no brand file: facts and banned terms not checked"))
        if not rep.items:
            print("PASS — no issues found.")
        for i in sorted(rep.items, key=lambda x: x["level"] != "FAIL"):
            print(f"{i['level']:4}  {i['where']}: {i['message']}")
        print(f"\n{len(rep.fails)} FAIL, {len(rep.items) - len(rep.fails)} WARN")
    sys.exit(1 if rep.fails else 0)


if __name__ == "__main__":
    main()
